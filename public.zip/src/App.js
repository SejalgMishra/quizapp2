import './App.css';

function App() {
  return (
    <div className="App">
      <h1>hellooo</h1>
    </div>
  );
}

export default App;
