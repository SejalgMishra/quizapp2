import React from 'react'

const Question = () => {
  return (
    <div>
        <h1>Question</h1>
    </div>
  )
}

export default Question